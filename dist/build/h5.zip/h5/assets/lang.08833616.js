var a="/static/lang.png";export{a as _};
